<?php
$host = explode('?', $_SERVER['REQUEST_URI'])[0];
$num=substr_count($host,'/');
$path  = explode('/', $host)[$num];

if ($path == '' OR $path == 'index.php' OR $path == 'index'){
	// start admin
	$response = ControllerAdmin::startAdmin();
}
//------------------------- Выход ------------------------
elseif ($path == 'logout') {
	//Выход
	$response = ControllerAdmin::logoutAdmin();
}

//----------------------News
elseif ($path == 'newsAction'){
	$response = ControllerNews::newsList();
}
elseif($path == 'addnews'){
	$response = ControllerNews::addNewsForm();
}

elseif($path == 'addnewsResult'){
	$response = ControllerNews::addNewsResult();
}
//----------------------------
elseif($path == 'editnews'){
	if(isset($_GET["id"])){
		$response = ControllerNews::editNewsForm($_GET["id"]);
	}else{
		$response = ControllerAdmin::error404();
	}
}
elseif($path == 'editnewsResult')  {
	if(isset($GET["id"])){
		$response = ControllerNews::editNewsResult($_GET["id"]);
	}else{
		$response = ControllerAdmin::error404();
	}
}


else{
	// Страница не сущестыует
	$response = ControllerAdmin::error404();
}


?>