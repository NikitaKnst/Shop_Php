<?php
class ModelCategory{

	//--------------------------List category
	public static function getCategoryActionList(){
		$sql = "SELECT * FROM category ORDER BY category.category ASC";
			$database = new database();
			$rows = $database->getAll($sql);
				return $rows;
	}

	
}


?>