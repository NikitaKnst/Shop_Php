<?php
class ModelNews{

//---------------------------List news
public static function getNewsActionList() {
	$sql = "SELECT news.*, category.* FROM news,category WHERE news.idCategory=category.idCategory ORDER BY news.date DESC";
	//создать экземпляр класса database
	$database = new database();
	//$rows = массив данных
	$rows = $database->getAll($sql);
	//---------------------------------------------
	return $rows;
}

public static function addNews() {
		$result=false;
		if(isset($_POST['save'])){
			if(isset($_POST['title']) && isset($_POST['description']) && isset($_POST['category'])	) {
				$title=$_POST['title'];
				$text=$_POST['description'];
				$idCategory=$_POST['category'];
				$date=date('Y-m-d');
				//------------------- закачка картинок на сервер
					$image = $_FILES['picture']['name']; //
					if($image!=""){
					$uploadfile = '../images/'. basename($_FILES['picture']['name']);
					copy($_FILES['picture']['tmp_name'], $uploadfile);
					}
					//-------------------запрос insert в бд
					$sql="INSERT INTO news 	(idNews, idCategory, title, newsText, date, newsPicture) VALUES (NULL, '$idCategory', '$title', '$text', '$date', '$image')";
					$database = new database();
					$item = $database->executeRun($sql);//результат INSERT
						if($item==true) {
							$result=true;
						}
			}//если данные в форме заполнены
		}//if нажаты кнопка send

		return $result;
	}//end add
	//-----------------------------------detail news
	public static function getNewsDetail($id)  {
		$sql = "SELECT news.*, category.* FROM news, category WHERE news.idCategory=category.idCategory AND news.idNews=$id ";
		$database = new database();
		$row = $database->getOne($sql);
		return $row;
	}

	public static function editNews($id){
		$result=false;
		if(isset($_POST['save'])){
			if(isset($_POST['title']) && isset($_POST['description']) && isset($_POST['category']) ){
				$title=$_POST['title'];
				$description=$_POST['description'];
				$idCategory=$_POST['category'];
				$date=$_POST['date'];
				$oldpicture=$_POST['oldpicture'];
				//-------------------images
					$image = $_FILES['picture']['name'];
					if($image!="" and $image!=$oldpicture){//загрузка новой картинки если выбрана
						$uploadfile = '../images'.basename($_FILES['picture']['name']);
						copy($_FILES['picture']['tmp_name'], $uploadfile);
						unlink("../images/".$oldpicture);//удаляем старую картинку
					}
					else{
						$image = $oldpicture;// оставим старую если нет новой
					}
					//-----------------------------------------------------------------
					$sql="UPDATE news SET idCategory = '$idCategory', title = '$title', newsText = '$description', date = '$date', newsPicture = '$image' WHERE news.idNews = $id";
					$database = new database();
					$item = $databse->executeRun($sql);
						$result=true;

			}//isset $_post
		}//save
		return $result;
	}//function
}//end class
//-----------------------Add News
	

?>