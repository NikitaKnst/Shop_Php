<?php
class ControllerAdmin {
	//--------------------start controll
	public static function startAdmin() {
		include_once('viewAdmin/dashboard.php');
	}
	//----------------------admin logout
	public static function logoutAdmin() {
		ModelAdmin::getAdminLogout();
		header('Location:../');//возврат на клиент часть сайта
	}

	//------------- страница error
	public static function error404(){
		include_once('viewAdmin/error404.php');
	}
	

}//end class
?>