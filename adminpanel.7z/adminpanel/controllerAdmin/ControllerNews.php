<?php

class ControllerNews {

	public static function newsList()	{
		//получить список новостей
		$rows = ModelNews::getNewsActionList();
		include_once('viewAdmin/newsActionList.php');
	}

	//add news form
	public static function addNewsForm()	{
		//получить список категорий для формы add news
			$rowsCategory = ModelCategory::getCategoryActionList();
			include_once('viewAdmin/newsAddForm.php');
	}
	//----------------------------------add news result
	public static function addNewsResult()		{
		$result = ModelNews::addNews();
		include_once('viewAdmin/newsAddForm.php');
	}

	public static function editNewsForm($id){
		$rowsCategory = ModelCategory::getCategoryActionList(); //список категорий
		$rowNews=ModelNews::getNewsDetail($id);//одна новость
		include_once('viewAdmin/newsEdditForm.php');
	}

	public static function editNewsResult($id){
		$result = ModelNews::editNews($id); // обработка формы edit
		include_once('viewAdmin/newsEdditForm.php');
	}
	
}
?>